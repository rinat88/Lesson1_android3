package com.example.lesson1_android3.lesson1.utils;

public interface OnItemClick {
    void position(String id);
}
